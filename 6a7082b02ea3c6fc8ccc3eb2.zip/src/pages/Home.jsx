const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useState, useRef, useCallback } from "react";

import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import ContaSelector from "@/components/notas/ContaSelector";
import OlistConexaoPanel from "@/components/notas/OlistConexaoPanel";
import NotasTable from "@/components/notas/NotasTable";
import LogPanel from "@/components/notas/LogPanel";
import {
  ShieldCheck,
  Loader2,
  Search,
  Square,
} from "lucide-react";

export default function Home() {
  const [conta, setConta] = useState("dugu");
  const [notas, setNotas] = useState([]);
  const [logs, setLogs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [running, setRunning] = useState(false);
  const [currentId, setCurrentId] = useState(null);
  const [progress, setProgress] = useState(0);
  const cancelRef = useRef(false);

  const addLog = useCallback((message, type = "info") => {
    setLogs((prev) => [
      ...prev,
      { type, message, timestamp: new Date().toISOString() },
    ]);
  }, []);

  const limparLogs = () => setLogs([]);

  const buscarNotas = async () => {
    setLoading(true);
    setNotas([]);
    setLogs([]);
    addLog("Buscando Notas Pendentes...");
    try {
      const res = await db.functions.invoke("listarPendentes", { conta });
      const data = res.data;
      if (data.error) throw new Error(data.error);
      const notasFormatadas = (data.notas || []).map((n) => ({
        ...n,
        status: n.descricaoSituacao || "Pendente",
        dataFormatted: n.data || "\u2014",
      }));
      setNotas(notasFormatadas);
      addLog(`${notasFormatadas.length} nota(s) encontrada(s).`, "success");
    } catch (e) {
      const msg = e?.response?.data?.error || e.message;
      addLog(`Erro ao buscar notas: ${msg}`, "error");
    } finally {
      setLoading(false);
    }
  };

  const processarNota = async (nota) => {
    setCurrentId(nota.id);
    setNotas((prev) =>
      prev.map((n) => (n.id === nota.id ? { ...n, status: "Processando" } : n))
    );

    try {
      const res = await db.functions.invoke("autorizarNota", {
        notaId: nota.id,
        conta,
      });
      const data = res.data;

      if (data.logs) {
        setLogs((prev) => [...prev, ...data.logs]);
      }

      if (data.success) {
        setNotas((prev) =>
          prev.map((n) =>
            n.id === nota.id ? { ...n, status: "Autorizada" } : n
          )
        );
      } else {
        setNotas((prev) =>
          prev.map((n) => (n.id === nota.id ? { ...n, status: "Erro" } : n))
        );
        if (data.error) addLog(`Nota ${nota.numero || nota.id}: ${data.error}`, "error");
      }
    } catch (e) {
      const msg = e?.response?.data?.error || e.message;
      setNotas((prev) =>
        prev.map((n) => (n.id === nota.id ? { ...n, status: "Erro" } : n))
      );
      addLog(`Nota ${nota.numero || nota.id}: Erro inesperado - ${msg}`, "error");
    } finally {
      setCurrentId(null);
    }
  };

  const handleAutorizar = async (nota) => {
    setRunning(true);
    setProgress(0);
    await processarNota(nota);
    setRunning(false);
  };

  const autorizarTodas = async () => {
    setRunning(true);
    cancelRef.current = false;
    setProgress(0);
    const pendentes = notas.filter((n) => n.status === "Pendente");
    addLog(`Iniciando autorização em lote: ${pendentes.length} nota(s).`);

    for (let i = 0; i < pendentes.length; i++) {
      if (cancelRef.current) {
        addLog("Processo cancelado pelo usuário.", "warning");
        break;
      }
      await processarNota(pendentes[i]);
      setProgress(Math.round(((i + 1) / pendentes.length) * 100));
      if (i < pendentes.length - 1 && !cancelRef.current) {
        await new Promise((r) => setTimeout(r, 800));
      }
    }

    setRunning(false);
    if (!cancelRef.current) {
      addLog("Processo em lote concluído.", "success");
    }
  };

  const pendentesCount = notas.filter((n) => n.status === "Pendente").length;
  const autorizadasCount = notas.filter((n) => n.status === "Autorizada").length;
  const errosCount = notas.filter((n) => n.status === "Erro").length;

  return (
    <main className="min-h-screen bg-gradient-to-b from-muted/30 to-background">
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8 py-8">
        <header className="mb-8">
          <div className="flex items-center gap-3 mb-1">
            <div className="w-10 h-10 rounded-xl bg-primary flex items-center justify-center shadow-sm">
              <ShieldCheck className="w-5 h-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-2xl font-bold sm:text-3xl">
                Autorização de Notas Fiscais
              </h1>
              <p className="text-sm text-muted-foreground">
                Automação de autorização SEFAZ no ERP Olist
              </p>
            </div>
          </div>
        </header>

        <div className="grid gap-6 lg:grid-cols-[280px_1fr]">
          {/* Sidebar */}
          <div className="space-y-4">
            <div className="panel p-5">
              <h2 className="text-sm font-semibold mb-3">Conta / Empresa</h2>
              <ContaSelector conta={conta} onChange={setConta} disabled={running} />
            </div>

            <OlistConexaoPanel />

            <div className="panel p-5">
              <h2 className="text-sm font-semibold mb-3">Ações</h2>
              <div className="space-y-2">
                <Button
                  onClick={buscarNotas}
                  disabled={loading || running}
                  variant="secondary"
                  className="w-full gap-2"
                >
                  {loading ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Search className="w-4 h-4" />
                  )}
                  {loading ? "Buscando..." : "Buscar Notas Pendentes"}
                </Button>
                {notas.length > 0 && pendentesCount > 0 && (
                  <Button
                    onClick={autorizarTodas}
                    disabled={running}
                    className="w-full gap-2"
                  >
                    {running ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <ShieldCheck className="w-4 h-4" />
                    )}
                    Autorizar Todas ({pendentesCount})
                  </Button>
                )}
                {running && (
                  <Button
                    onClick={() => {
                      cancelRef.current = true;
                    }}
                    variant="destructive"
                    className="w-full gap-2"
                  >
                    <Square className="w-4 h-4" />
                    Parar
                  </Button>
                )}
              </div>
            </div>

            {notas.length > 0 && (
              <div className="panel p-5 space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Pendentes</span>
                  <span className="font-semibold">{pendentesCount}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Autorizadas</span>
                  <span className="font-semibold text-emerald-600">
                    {autorizadasCount}
                  </span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-muted-foreground">Erros</span>
                  <span className="font-semibold text-red-600">{errosCount}</span>
                </div>
                {running && <Progress value={progress} className="h-1.5 mt-2" />}
              </div>
            )}
          </div>

          {/* Main content */}
          <div className="space-y-6">
            <div className="panel overflow-hidden">
              <div className="flex items-center justify-between px-6 py-4 border-b border-border">
                <h2 className="text-lg font-semibold">Notas Fiscais Pendentes</h2>
                {notas.length > 0 && (
                  <span className="text-sm text-muted-foreground">
                    {notas.length} nota(s)
                  </span>
                )}
              </div>
              {loading ? (
                <div className="flex items-center justify-center py-16">
                  <Loader2 className="w-8 h-8 animate-spin text-muted-foreground" />
                </div>
              ) : (
                <NotasTable
                  notas={notas}
                  onAutorizar={handleAutorizar}
                  running={running}
                  currentId={currentId}
                />
              )}
            </div>

            {logs.length > 0 && <LogPanel logs={logs} onClear={limparLogs} />}
          </div>
        </div>
      </div>
    </main>
  );
}