import React, { useRef, useEffect } from "react";
import { Terminal, Trash2 } from "lucide-react";

const COLORS = {
  info: "text-slate-300",
  success: "text-emerald-400",
  error: "text-red-400",
  warning: "text-amber-400",
};

const ICONS = {
  info: "\u2192",
  success: "\u2713",
  error: "\u2717",
  warning: "\u26A0",
};

export default function LogPanel({ logs, onClear }) {
  const scrollRef = useRef(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [logs]);

  return (
    <div className="rounded-xl border border-slate-700/50 bg-slate-900 shadow-sm overflow-hidden">
      <div className="flex items-center justify-between px-4 py-3 border-b border-slate-700/50">
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-slate-400" />
          <span className="text-sm font-medium text-slate-200">Logs em tempo real</span>
        </div>
        <div className="flex items-center gap-3">
          {logs.length > 0 && (
            <span className="text-xs text-slate-500">{logs.length} eventos</span>
          )}
          {onClear && logs.length > 0 && (
            <button
              onClick={onClear}
              className="text-slate-500 hover:text-slate-300 transition-colors"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>
      <div
        ref={scrollRef}
        className="overflow-y-auto p-4 space-y-1 bg-slate-900 log-scroll max-h-[400px]"
      >
        {logs.length === 0 ? (
          <p className="text-slate-600 text-sm text-center py-8">Aguardando execu\u00e7\u00e3o...</p>
        ) : (
          logs.map((log, i) => (
            <div
              key={i}
              className={`text-xs font-mono leading-relaxed animate-fade-in-up ${
                COLORS[log.type] || "text-slate-300"
              }`}
            >
              <span className="text-slate-600 mr-2 select-none">
                {new Date(log.timestamp).toLocaleTimeString("pt-BR")}
              </span>
              <span className="mr-1.5 select-none">{ICONS[log.type] || "\u2192"}</span>
              {log.message}
            </div>
          ))
        )}
      </div>
    </div>
  );
}