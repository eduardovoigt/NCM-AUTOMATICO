import React from "react";

const CONTAS = [
  { id: "dugu", nome: "DUGU ATACADISTA" },
  { id: "fadrilar", nome: "FADRILAR" },
];

export default function ContaSelector({ conta, onChange, disabled }) {
  return (
    <div className="grid grid-cols-1 gap-2">
      {CONTAS.map((c) => (
        <button
          key={c.id}
          type="button"
          disabled={disabled}
          onClick={() => onChange(c.id)}
          className={`rounded-xl border px-4 py-2.5 text-sm font-semibold transition-all ${
            conta === c.id
              ? "border-primary bg-primary/10 text-primary shadow-sm"
              : "border-border bg-card text-muted-foreground hover:text-foreground hover:border-primary/30"
          } disabled:opacity-50 disabled:cursor-not-allowed`}
        >
          {c.nome}
        </button>
      ))}
    </div>
  );
}