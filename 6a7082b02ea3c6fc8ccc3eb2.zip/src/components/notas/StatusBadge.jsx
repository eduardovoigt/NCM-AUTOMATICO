import React from "react";

const STATUS_CONFIG = {
  Pendente: { label: "Pendente", cls: "bg-amber-100 text-amber-700" },
  Processando: { label: "Processando", cls: "bg-blue-100 text-blue-700" },
  Autorizada: { label: "Autorizada", cls: "bg-emerald-100 text-emerald-700" },
  Erro: { label: "Erro", cls: "bg-red-100 text-red-700" },
};

export default function StatusBadge({ status }) {
  const config = STATUS_CONFIG[status] || STATUS_CONFIG.Pendente;
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium ${config.cls}`}
    >
      {config.label}
    </span>
  );
}