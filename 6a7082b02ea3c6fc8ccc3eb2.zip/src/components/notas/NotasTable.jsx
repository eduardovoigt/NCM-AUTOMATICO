import React from "react";
import { Button } from "@/components/ui/button";
import StatusBadge from "./StatusBadge";
import { Loader2, ShieldCheck, FileText } from "lucide-react";

export default function NotasTable({ notas, onAutorizar, running, currentId }) {
  if (notas.length === 0) {
    return (
      <div className="text-center py-16">
        <FileText className="w-12 h-12 text-muted-foreground/30 mx-auto mb-3" />
        <p className="text-sm text-muted-foreground">
          Clique em &quot;Buscar Notas Pendentes&quot; para carregar as notas.
        </p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full text-left text-sm">
        <thead>
          <tr className="border-b border-border text-xs uppercase tracking-wide text-muted-foreground">
            <th className="py-3 px-4 font-medium">Nota Fiscal</th>
            <th className="py-3 px-4 font-medium">Pedido</th>
            <th className="py-3 px-4 font-medium">Cliente</th>
            <th className="py-3 px-4 font-medium">Marketplace</th>
            <th className="py-3 px-4 font-medium">Data</th>
            <th className="py-3 px-4 font-medium">Status</th>
            <th className="py-3 px-4 font-medium text-right">Ação</th>
          </tr>
        </thead>
        <tbody>
          {notas.map((nota) => {
            const isProcessing = running && currentId === nota.id;
            return (
              <tr
                key={nota.id}
                className="border-b border-border/40 transition-colors hover:bg-muted/30"
              >
                <td className="py-3 px-4 font-mono text-xs font-medium">
                  {nota.numero || nota.id}
                </td>
                <td className="py-3 px-4 font-mono text-xs text-muted-foreground">
                  {nota.numeroEcommerce || "\u2014"}
                </td>
                <td className="py-3 px-4 max-w-[180px] truncate" title={nota.cliente}>
                  {nota.cliente || "\u2014"}
                </td>
                <td className="py-3 px-4 text-xs text-muted-foreground">
                  {nota.marketplace || "\u2014"}
                </td>
                <td className="py-3 px-4 text-xs text-muted-foreground">
                  {nota.dataFormatted || "\u2014"}
                </td>
                <td className="py-3 px-4">
                  <StatusBadge status={nota.status} />
                </td>
                <td className="py-3 px-4 text-right">
                  <Button
                    size="sm"
                    onClick={() => onAutorizar(nota)}
                    disabled={running || nota.status === "Autorizada"}
                    className="gap-1.5"
                  >
                    {isProcessing ? (
                      <>
                        <Loader2 className="w-3.5 h-3.5 animate-spin" />
                        Processando
                      </>
                    ) : (
                      <>
                        <ShieldCheck className="w-3.5 h-3.5" />
                        Autorizar na SEFAZ
                      </>
                    )}
                  </Button>
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}