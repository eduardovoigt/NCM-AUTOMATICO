const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import React, { useCallback, useEffect, useState } from "react";

import { Loader2, KeyRound } from "lucide-react";
import OlistConexaoItem from "@/components/notas/OlistConexaoItem";

export default function OlistConexaoPanel() {
  const [empresas, setEmpresas] = useState([]);
  const [redirectUri, setRedirectUri] = useState("");
  const [podeGerenciar, setPodeGerenciar] = useState(false);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(null);
  const [mensagem, setMensagem] = useState(null);

  const carregar = useCallback(async () => {
    const res = await db.functions.invoke("olistConexaoStatus", {});
    if (res.data?.error) throw new Error(res.data.error);
    setEmpresas(res.data.empresas || []);
    setRedirectUri(res.data.redirectUri || "");
    setPodeGerenciar(Boolean(res.data.podeGerenciar));
  }, []);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const resultado = params.get("olist");
    if (resultado) {
      const conta = params.get("conta");
      setMensagem(
        resultado === "ok"
          ? { tipo: "sucesso", texto: `Autorização concluída${conta ? ` (${conta.toUpperCase()})` : ""}.` }
          : { tipo: "erro", texto: params.get("motivo") || "Falha na autorização." }
      );
      params.delete("olist");
      params.delete("conta");
      params.delete("motivo");
      const query = params.toString();
      window.history.replaceState({}, "", `${window.location.pathname}${query ? `?${query}` : ""}`);
    }
    carregar()
      .catch((e) => setMensagem({ tipo: "erro", texto: e?.response?.data?.error || e.message }))
      .finally(() => setLoading(false));
  }, [carregar]);

  const conectar = async (conta) => {
    setBusy(conta);
    setMensagem(null);
    try {
      const res = await db.functions.invoke("olistOauthIniciar", { conta });
      if (res.data?.error) throw new Error(res.data.error);
      window.location.href = res.data.url;
    } catch (e) {
      setMensagem({ tipo: "erro", texto: e?.response?.data?.error || e.message });
      setBusy(null);
    }
  };

  const desconectar = async (conta) => {
    setBusy(conta);
    setMensagem(null);
    try {
      const res = await db.functions.invoke("olistDesconectar", { conta });
      if (res.data?.error) throw new Error(res.data.error);
      await carregar();
      setMensagem({ tipo: "sucesso", texto: `Conexão de ${conta.toUpperCase()} removida.` });
    } catch (e) {
      setMensagem({ tipo: "erro", texto: e?.response?.data?.error || e.message });
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="panel p-5 space-y-3">
      <div className="flex items-center gap-2">
        <KeyRound className="w-4 h-4 text-muted-foreground" />
        <h2 className="text-sm font-semibold">Conexão OAuth V3</h2>
      </div>

      {loading ? (
        <div className="flex justify-center py-4">
          <Loader2 className="w-5 h-5 animate-spin text-muted-foreground" />
        </div>
      ) : (
        <div className="space-y-2">
          {empresas.map((empresa) => (
            <OlistConexaoItem
              key={empresa.conta}
              empresa={empresa}
              busy={busy === empresa.conta}
              podeGerenciar={podeGerenciar}
              onConectar={conectar}
              onDesconectar={desconectar}
            />
          ))}
          {!podeGerenciar && (
            <p className="text-xs text-muted-foreground">
              Apenas administradores podem conectar ou desconectar empresas.
            </p>
          )}
        </div>
      )}

      {mensagem && (
        <p className={`text-xs break-words ${mensagem.tipo === "erro" ? "text-red-600" : "text-emerald-700"}`}>
          {mensagem.texto}
        </p>
      )}

      {redirectUri && (
        <div className="pt-1 border-t border-border space-y-1">
          <p className="text-xs text-muted-foreground">URL de redirecionamento para cadastrar no Olist:</p>
          <p className="text-xs font-mono break-all text-foreground">{redirectUri}</p>
        </div>
      )}
    </div>
  );
}