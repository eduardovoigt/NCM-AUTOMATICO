import React from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Loader2, Link2, Unlink } from "lucide-react";

const STATUS = {
  conectado: { label: "Conectado", className: "bg-emerald-100 text-emerald-700 border-emerald-200" },
  pendente: { label: "Aguardando autorização", className: "bg-amber-100 text-amber-700 border-amber-200" },
  erro: { label: "Erro", className: "bg-red-100 text-red-700 border-red-200" },
  desconectado: { label: "Desconectado", className: "bg-slate-100 text-slate-600 border-slate-200" },
};

function formatarData(iso) {
  if (!iso) return "—";
  return new Date(iso).toLocaleString("pt-BR");
}

export default function OlistConexaoItem({ empresa, busy, podeGerenciar, onConectar, onDesconectar }) {
  const status = STATUS[empresa.status] || STATUS.desconectado;

  return (
    <div className="rounded-lg border border-border p-3 space-y-2">
      <div className="flex items-start justify-between gap-2">
        <div className="min-w-0">
          <p className="text-sm font-medium truncate">{empresa.nome}</p>
          <p className="text-xs text-muted-foreground">
            {empresa.conectada ? `Token expira em ${formatarData(empresa.expiraEm)}` : "Sem autorização OAuth V3"}
          </p>
        </div>
        <Badge variant="outline" className={`shrink-0 ${status.className}`}>
          {status.label}
        </Badge>
      </div>

      {!empresa.configurada && (
        <p className="text-xs text-amber-700">
          Client ID / Client Secret não configurados para esta empresa.
        </p>
      )}
      {empresa.ultimoErro && (
        <p className="text-xs text-red-600 break-words">{empresa.ultimoErro}</p>
      )}

      <div className="flex gap-2">
        <Button
          size="sm"
          variant={empresa.conectada ? "outline" : "default"}
          className="gap-1.5"
          disabled={busy || !podeGerenciar || !empresa.configurada}
          onClick={() => onConectar(empresa.conta)}
        >
          {busy ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Link2 className="w-3.5 h-3.5" />}
          {empresa.conectada ? "Reconectar" : "Conectar"}
        </Button>
        {empresa.conectada && (
          <Button
            size="sm"
            variant="ghost"
            className="gap-1.5 text-muted-foreground"
            disabled={busy || !podeGerenciar}
            onClick={() => onDesconectar(empresa.conta)}
          >
            <Unlink className="w-3.5 h-3.5" />
            Desconectar
          </Button>
        )}
      </div>
    </div>
  );
}