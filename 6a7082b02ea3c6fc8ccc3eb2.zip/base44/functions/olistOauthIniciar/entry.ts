const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from "npm:@base44/sdk@0.8.54";
import {
  credenciais,
  empresaPorId,
  montarUrlAutorizacao,
  salvarConexao,
  urlCallback,
} from "../../shared/olist-oauth.ts";

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await db.auth
      .me()
      .catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: "Não autorizado" }, { status: 401 });
    if (user.role !== "admin") {
      return Response.json(
        { error: "Somente administradores podem conectar empresas ao Olist." },
        { status: 403 }
      );
    }

    const { conta } = await req.json().catch(() => ({}));
    if (!conta) {
      return Response.json({ error: "Informe a empresa (conta)." }, { status: 400 });
    }

    const empresa = empresaPorId(conta);
    const { clientId } = credenciais(empresa);
    const redirectUri = urlCallback(req);
    const state = crypto.randomUUID();

    await salvarConexao(base44, conta, {
      oauth_state: state,
      oauth_state_expira_em: new Date(Date.now() + 10 * 60 * 1000).toISOString(),
      redirect_uri_usado: redirectUri,
      status: "pendente",
      ultimo_erro: null,
    });

    return Response.json({
      conta,
      url: montarUrlAutorizacao({ clientId, redirectUri, state }),
      redirectUri,
    });
  } catch (error) {
    const status = /não configuradas|Empresa inválida/.test(error.message) ? 400 : 500;
    return Response.json({ error: error.message }, { status });
  }
}