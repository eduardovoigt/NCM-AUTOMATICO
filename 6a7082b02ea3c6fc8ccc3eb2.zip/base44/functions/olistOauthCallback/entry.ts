const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from "npm:@base44/sdk@0.8.54";
import {
  dadosToken,
  empresaPorId,
  trocarCodigoPorToken,
  urlApp,
  urlCallback,
} from "../../shared/olist-oauth.ts";

export default async function (req) {
  const params = new URL(req.url).searchParams;
  const code = params.get("code");
  const state = params.get("state");
  const erroOauth = params.get("error");
  const descricao = params.get("error_description");

  let origemApp = null;
  try {
    origemApp = urlApp(req);
  } catch {
    origemApp = null;
  }

  const responder = (dados) => {
    if (!origemApp) return Response.json(dados, { status: 400 });
    const destino = new URL(origemApp + "/");
    Object.entries(dados).forEach(([chave, valor]) => {
      if (valor) destino.searchParams.set(chave, valor);
    });
    return Response.redirect(destino.toString(), 302);
  };

  if (erroOauth) {
    return responder({ olist: "erro", motivo: descricao || erroOauth });
  }
  if (!code || !state) {
    return responder({ olist: "erro", motivo: "Callback sem código de autorização." });
  }

  try {
    const base44 = createClientFromRequest(req);
    const registros = await db.asServiceRole.entities.OlistConexao.filter({
      oauth_state: state,
    });
    const conexao = registros[0];
    if (!conexao) {
      return responder({
        olist: "erro",
        motivo: "Estado de autorização inválido. Inicie a conexão novamente.",
      });
    }
    if (
      conexao.oauth_state_expira_em &&
      new Date(conexao.oauth_state_expira_em).getTime() < Date.now()
    ) {
      return responder({
        olist: "erro",
        motivo: "A autorização expirou. Inicie a conexão novamente.",
      });
    }

    const empresa = empresaPorId(conexao.conta);
    const redirectUri = conexao.redirect_uri_usado || urlCallback(req);
    const tokens = await trocarCodigoPorToken(empresa, code, redirectUri);

    await db.asServiceRole.entities.OlistConexao.update(conexao.id, {
      ...dadosToken(tokens),
      oauth_state: null,
      oauth_state_expira_em: null,
    });

    return responder({ olist: "ok", conta: conexao.conta });
  } catch (error) {
    try {
      const base44 = createClientFromRequest(req);
      const registros = await db.asServiceRole.entities.OlistConexao.filter({
        oauth_state: state,
      });
      if (registros[0]) {
        await db.asServiceRole.entities.OlistConexao.update(registros[0].id, {
          status: "erro",
          ultimo_erro: error.message,
        });
      }
    } catch {
      // se nem o registro de erro funcionar, apenas devolvemos a falha original
    }
    return responder({ olist: "erro", motivo: error.message });
  }
}