const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from "npm:@base44/sdk@0.8.40";
import { listarNotasPendentes } from "../../shared/olist-api.ts";

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await db.auth.me();
    if (!user) return Response.json({ error: "Não autorizado" }, { status: 401 });

    const body = await req.json();
    const conta = body?.conta;
    if (!conta) return Response.json({ error: "Conta é obrigatória" }, { status: 400 });

    let todasNotas = [];
    let pagina = 1;
    let totalPaginas = 1;
    while (pagina <= totalPaginas && pagina <= 10) {
      const result = await listarNotasPendentes(conta, pagina);
      todasNotas = todasNotas.concat(result.notas);
      totalPaginas = result.paginas;
      pagina++;
    }

    return Response.json({ notas: todasNotas, total: todasNotas.length });
  } catch (error) {
    if (String(error.message).toLowerCase().includes("n\u00e3o retornou") || String(error.message).toLowerCase().includes("nao retornou")) {
      return Response.json({ notas: [], total: 0 });
    }
    return Response.json({ error: error.message }, { status: 500 });
  }
}