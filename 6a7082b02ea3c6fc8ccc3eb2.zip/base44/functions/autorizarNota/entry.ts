const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from "npm:@base44/sdk@0.8.40";
import {
  obterNota,
  extrairItens,
  formatarNcm,
  montarNotaParaSalvar,
  alterarNotaFiscal,
  emitirNota,
  matchNcm,
  isNcmError,
  NCM_CONTINGENCIA,
} from "../../shared/olist-api.ts";

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await db.auth.me();
    if (!user) return Response.json({ error: "Não autorizado" }, { status: 401 });

    const body = await req.json();
    const conta = body?.conta;
    let notaId = body?.notaId;
    if (!notaId || !conta)
      return Response.json({ error: "notaId e conta são obrigatórios" }, { status: 400 });

    const logs = [];
    const addLog = (message, type = "info") =>
      logs.push({ type, message, timestamp: new Date().toISOString() });

    // ================================================================
    // FASE 1 — ABRIR A NOTA FISCAL E LER OS ITENS
    // ================================================================
    addLog(`Abrindo Nota Fiscal ${notaId}...`);
    let nota;
    try {
      nota = await obterNota(notaId, conta);
    } catch (e) {
      addLog(`Não foi possível abrir a Nota Fiscal: ${e.message}`, "error");
      return Response.json({ success: false, logs, error: e.message });
    }

    addLog(
      `Nota lida — id=${nota?.id}, numero=${nota?.numero}, serie=${nota?.serie}, ` +
        `situacao=${nota?.situacao}, id_venda=${nota?.id_venda ?? "[não encontrado]"}`
    );

    addLog("Lendo produtos...");
    let itens = extrairItens(nota);
    addLog(`${itens.length} produto(s) encontrado(s).`);

    for (let i = 0; i < itens.length; i++) {
      addLog(
        `Produto ${i + 1}: id_produto=${itens[i].id_produto || "0"} | ` +
          `NCM=${itens[i].ncm || "[vazio]"} | "${(itens[i].descricao || "").substring(0, 60)}"`
      );
    }

    // ================================================================
    // FASE 2 — CORRIGIR NCM NOS ITENS DA NOTA FISCAL
    // ================================================================
    let itemsModified = false;
    for (let i = 0; i < itens.length; i++) {
      const ncmRaw = itens[i].ncm;
      if (!ncmRaw || ncmRaw.length < 8) {
        const oldNcm = ncmRaw || "[vazio]";
        const matched = matchNcm(itens[i].descricao);
        const newNcmDigits = matched ?? NCM_CONTINGENCIA;
        const newNcmFormatted = formatarNcm(newNcmDigits);

        addLog(
          `Item ${i + 1} — id_produto=${itens[i].id_produto || "0"}, ` +
            `nome="${(itens[i].descricao || "").substring(0, 60)}", ` +
            `NCM antigo: ${oldNcm}, NCM novo: ${newNcmFormatted}`,
          matched ? "success" : "warning"
        );

        itens[i].ncm = newNcmFormatted;
        itemsModified = true;
      }
    }

    if (!itemsModified) {
      addLog("Nenhuma correção necessária. Prosseguindo para autorização.");
    }

    // ================================================================
    // FASE 3 — SALVAR A NOTA FISCAL (EDITAR O ITEM DIRETAMENTE)
    // ================================================================
    if (itemsModified) {
      addLog(`Salvando Nota Fiscal ${notaId}...`);
      addLog(`Endpoint: nota.fiscal.alterar.php | Método: POST`);
      addLog(`URL: https://api.tiny.com.br/api2/nota.fiscal.alterar.php`);

      const notaParaSalvar = montarNotaParaSalvar(nota, itens);

      try {
        const resultado = await alterarNotaFiscal(notaId, notaParaSalvar, conta);
        addLog(`Nota Fiscal salva — ID: ${resultado.id}`, "success");

        // --- FASE 3b — CONFIRMAR VIA API QUE O NCM FOI PERSISTIDO ---
        addLog("Confirmando gravação do NCM via API...");
        const notaReleitura = await obterNota(resultado.id, conta);
        const itensReleitura = extrairItens(notaReleitura);
        let ncmOk = true;
        for (let i = 0; i < itensReleitura.length; i++) {
          const ncmReleitura = itensReleitura[i].ncm;
          addLog(`Validação item ${i + 1}: NCM=${ncmReleitura || "[vazio]"}`);
          if (!ncmReleitura || ncmReleitura.length < 8) {
            ncmOk = false;
            addLog(`NCM não persistido no item ${i + 1} após salvamento.`, "warning");
          }
        }
        if (ncmOk) {
          addLog("NCM confirmado em todos os itens.", "success");
          notaId = resultado.id;
        } else {
          addLog("Atenção: NCM pode não ter sido persistido em todos os itens.", "warning");
        }
      } catch (e) {
        addLog(`Erro ao salvar nota: ${e.message}`, "error");
        return Response.json({ success: false, logs, error: e.message });
      }
    }

    // ================================================================
    // FASE 4 — AUTORIZAR NA SEFAZ
    // ================================================================
    addLog(`Autorizando Nota ${notaId} na SEFAZ...`);
    let autorizada = false;
    let erroMsg = "";

    try {
      await emitirNota(notaId, conta);
      await new Promise((r) => setTimeout(r, 2000));
      try {
        const att = await obterNota(notaId, conta);
        const sit = String(att.situacao ?? "").toLowerCase();
        const descSit = String(att.descricao_situacao ?? "").toLowerCase();
        if (sit === "6" || descSit.includes("autorizada") || descSit.includes("autorizado")) {
          autorizada = true;
          addLog("Nota autorizada com sucesso.", "success");
        } else if (descSit.includes("rejeitada") || descSit.includes("cancelada")) {
          erroMsg = att.motivo_rejeicao ?? att.observacao ?? "Nota rejeitada pela SEFAZ.";
          addLog(`Nota rejeitada: ${erroMsg}`, "error");
        } else {
          autorizada = true;
          addLog("Nota enviada para SEFAZ. Aguardando processamento.", "info");
        }
      } catch {
        autorizada = true;
        addLog("Nota enviada para SEFAZ. Aguardando processamento.", "info");
      }
    } catch (e) {
      erroMsg = e.message;
      addLog(`Erro na autorização: ${erroMsg}`, "error");
    }

    // ================================================================
    // FASE 5 — RETENTATIVA APÓS ERRO DE NCM
    // ================================================================
    if (!autorizada && isNcmError(erroMsg)) {
      addLog("Erro de NCM detectado na SEFAZ. Reeditando nota...", "warning");
      try {
        const notaRetry = await obterNota(notaId, conta);
        const itensRetry = extrairItens(notaRetry);
        for (let i = 0; i < itensRetry.length; i++) {
          if (!itensRetry[i].ncm || itensRetry[i].ncm.length < 8) {
            const matched = matchNcm(itensRetry[i].descricao);
            const newNcm = formatarNcm(matched ?? NCM_CONTINGENCIA);
            addLog(`Recorreção item ${i + 1}: NCM ${itensRetry[i].ncm || "[vazio]"} → ${newNcm}`);
            itensRetry[i].ncm = newNcm;
          }
        }
        const notaParaSalvar2 = montarNotaParaSalvar(notaRetry, itensRetry);
        await alterarNotaFiscal(notaId, notaParaSalvar2, conta);
        addLog("Nota reeditada. Tentando autorização novamente...");

        await emitirNota(notaId, conta);
        await new Promise((r) => setTimeout(r, 2000));
        try {
          const att = await obterNota(notaId, conta);
          const sit = String(att.situacao ?? "").toLowerCase();
          const descSit = String(att.descricao_situacao ?? "").toLowerCase();
          if (sit === "6" || descSit.includes("autorizada") || descSit.includes("autorizado")) {
            autorizada = true;
            addLog("Nota autorizada com sucesso (2ª tentativa).", "success");
          } else if (descSit.includes("rejeitada") || descSit.includes("cancelada")) {
            erroMsg = att.motivo_rejeicao ?? "Nota rejeitada pela SEFAZ após correção.";
            addLog(`Nota rejeitada novamente: ${erroMsg}`, "error");
          } else {
            autorizada = true;
            addLog("Nota enviada para SEFAZ (2ª tentativa).", "info");
          }
        } catch {
          autorizada = true;
          addLog("Nota enviada para SEFAZ (2ª tentativa). Aguardando.", "info");
        }
      } catch (e) {
        erroMsg = e.message;
        addLog(`Erro na segunda tentativa: ${erroMsg}`, "error");
      }
    }

    if (autorizada) {
      addLog("Processo concluído.", "success");
      return Response.json({
        success: true,
        logs,
        nota: { id: notaId, numero: nota?.numero ?? "" },
      });
    }
    return Response.json({ success: false, logs, error: erroMsg });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}