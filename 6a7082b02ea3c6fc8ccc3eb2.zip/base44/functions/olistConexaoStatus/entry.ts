const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from "npm:@base44/sdk@0.8.54";
import {
  EMPRESAS,
  buscarConexao,
  credenciaisConfiguradas,
  obterAccessTokenValido,
  urlCallback,
} from "../../shared/olist-oauth.ts";

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await db.auth
      .me()
      .catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: "Não autorizado" }, { status: 401 });

    const redirectUri = urlCallback(req);
    const empresas = [];

    for (const empresa of EMPRESAS) {
      let conexao = await buscarConexao(base44, empresa.id);
      let erroRenovacao = null;

      if (conexao?.access_token) {
        try {
          // Renova automaticamente quando o token está expirando.
          await obterAccessTokenValido(base44, empresa.id);
        } catch (e) {
          erroRenovacao = e.message;
        }
        conexao = await buscarConexao(base44, empresa.id);
      }

      empresas.push({
        conta: empresa.id,
        nome: empresa.nome,
        configurada: credenciaisConfiguradas(empresa),
        conectada: Boolean(conexao?.access_token),
        status: conexao?.status || "desconectado",
        conectadoEm: conexao?.conectado_em || null,
        expiraEm: conexao?.expira_em || null,
        refreshExpiraEm: conexao?.refresh_expira_em || null,
        ultimoErro: erroRenovacao || conexao?.ultimo_erro || null,
      });
    }

    return Response.json({
      empresas,
      redirectUri,
      podeGerenciar: user.role === "admin",
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}