const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { createClientFromRequest } from "npm:@base44/sdk@0.8.54";
import { buscarConexao, empresaPorId } from "../../shared/olist-oauth.ts";

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await db.auth
      .me()
      .catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: "Não autorizado" }, { status: 401 });
    if (user.role !== "admin") {
      return Response.json(
        { error: "Somente administradores podem desconectar empresas." },
        { status: 403 }
      );
    }

    const { conta } = await req.json().catch(() => ({}));
    if (!conta) {
      return Response.json({ error: "Informe a empresa (conta)." }, { status: 400 });
    }

    const empresa = empresaPorId(conta);
    const conexao = await buscarConexao(base44, conta);

    if (conexao) {
      await db.asServiceRole.entities.OlistConexao.update(conexao.id, {
        access_token: null,
        refresh_token: null,
        expira_em: null,
        refresh_expira_em: null,
        escopo: null,
        status: "desconectado",
        conectado_em: null,
        ultimo_erro: null,
        oauth_state: null,
        oauth_state_expira_em: null,
      });
    }

    return Response.json({ success: true, conta, nome: empresa.nome });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 400 });
  }
}