const db = globalThis.__B44_DB__ || { auth:{ isAuthenticated: async()=>false, me: async()=>null }, entities:new Proxy({}, { get:()=>({ filter:async()=>[], get:async()=>null, create:async()=>({}), update:async()=>({}), delete:async()=>({}) }) }), integrations:{ Core:{ UploadFile:async()=>({ file_url:'' }) } } };

import { secrets } from "base44:runtime";

// Endpoints oficiais da API V3 (OAuth 2.0 / OpenID Connect)
export const OLIST_AUTH_URL =
  "https://accounts.tiny.com.br/realms/tiny/protocol/openid-connect/auth";
export const OLIST_TOKEN_URL =
  "https://accounts.tiny.com.br/realms/tiny/protocol/openid-connect/token";

export const CALLBACK_FUNCTION = "olistOauthCallback";

// Cada empresa tem seu próprio aplicativo privado no Olist.
export const EMPRESAS = [
  {
    id: "dugu",
    nome: "DUGU ATACADISTA",
    clientIdSecret: "OLIST_DUGU_CLIENT_ID",
    clientSecretSecret: "OLIST_DUGU_CLIENT_SECRET",
  },
  {
    id: "fadrilar",
    nome: "FADRILAR",
    clientIdSecret: "OLIST_FADRILAR_CLIENT_ID",
    clientSecretSecret: "OLIST_FADRILAR_CLIENT_SECRET",
  },
];

const MARGEM_RENOVACAO_MS = 60 * 1000;

export function empresaPorId(id) {
  const empresa = EMPRESAS.find((e) => e.id === id);
  if (!empresa) throw new Error("Empresa inválida: " + id);
  return empresa;
}

export function credenciaisConfiguradas(empresa) {
  return Boolean(
    secrets.get(empresa.clientIdSecret) && secrets.get(empresa.clientSecretSecret)
  );
}

export function credenciais(empresa) {
  const clientId = secrets.get(empresa.clientIdSecret);
  const clientSecret = secrets.get(empresa.clientSecretSecret);
  if (!clientId || !clientSecret) {
    throw new Error(
      `Credenciais OAuth não configuradas para ${empresa.nome}. ` +
        `Cadastre os secrets ${empresa.clientIdSecret} e ${empresa.clientSecretSecret}.`
    );
  }
  return { clientId, clientSecret };
}

// Origem do app definida pelo servidor (nunca confiar em Origin do navegador).
export function urlApp(req) {
  const origem = req.headers.get("X-Base44-App-Url");
  if (!origem) throw new Error("Não foi possível determinar a URL pública do aplicativo.");
  return origem.replace(/\/+$/, "");
}

// Sempre derivado da origem do app + nome real da função publicada,
// para nunca divergir do caminho que o Olist precisa chamar.
export function urlCallback(req) {
  return `${urlApp(req)}/functions/${CALLBACK_FUNCTION}`;
}

export function montarUrlAutorizacao({ clientId, redirectUri, state }) {
  const params = new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUri,
    scope: "openid",
    response_type: "code",
    state,
  });
  return `${OLIST_AUTH_URL}?${params.toString()}`;
}

async function postToken(corpo) {
  const res = await fetch(OLIST_TOKEN_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams(corpo).toString(),
    signal: AbortSignal.timeout(20000),
  });
  const texto = await res.text();
  let json;
  try {
    json = JSON.parse(texto);
  } catch {
    throw new Error(`Resposta inválida do servidor de tokens (HTTP ${res.status}).`);
  }
  if (!res.ok || json.error) {
    const motivo = json.error_description || json.error || `HTTP ${res.status}`;
    throw new Error(`Falha na autenticação OAuth: ${motivo}`);
  }
  if (!json.access_token) throw new Error("O servidor de tokens não retornou access_token.");
  return json;
}

export async function trocarCodigoPorToken(empresa, code, redirectUri) {
  const { clientId, clientSecret } = credenciais(empresa);
  return await postToken({
    grant_type: "authorization_code",
    client_id: clientId,
    client_secret: clientSecret,
    redirect_uri: redirectUri,
    code,
  });
}

export async function renovarAccessToken(empresa, refreshToken) {
  const { clientId, clientSecret } = credenciais(empresa);
  return await postToken({
    grant_type: "refresh_token",
    client_id: clientId,
    client_secret: clientSecret,
    refresh_token: refreshToken,
  });
}

function emIso(segundos) {
  const n = Number(segundos);
  if (!Number.isFinite(n) || n <= 0) return null;
  return new Date(Date.now() + n * 1000).toISOString();
}

export function dadosToken(tokens) {
  return {
    access_token: tokens.access_token,
    refresh_token: tokens.refresh_token || null,
    expira_em: emIso(tokens.expires_in),
    refresh_expira_em: emIso(tokens.refresh_expires_in),
    escopo: tokens.scope || null,
    status: "conectado",
    conectado_em: new Date().toISOString(),
    ultimo_erro: null,
  };
}

export async function buscarConexao(base44, conta) {
  const registros = await db.asServiceRole.entities.OlistConexao.filter({ conta });
  return registros[0] || null;
}

export async function salvarConexao(base44, conta, dados) {
  const existente = await buscarConexao(base44, conta);
  if (existente) {
    return await db.asServiceRole.entities.OlistConexao.update(existente.id, dados);
  }
  return await db.asServiceRole.entities.OlistConexao.create({
    conta,
    empresa: empresaPorId(conta).nome,
    ...dados,
  });
}

// Usado pelas futuras chamadas V3: devolve um access token válido,
// renovando automaticamente com o refresh token quando estiver expirando.
export async function obterAccessTokenValido(base44, conta) {
  const empresa = empresaPorId(conta);
  const conexao = await buscarConexao(base44, conta);
  if (!conexao || !conexao.access_token) {
    throw new Error(`A empresa ${empresa.nome} ainda não está conectada ao Olist.`);
  }

  const expira = conexao.expira_em ? new Date(conexao.expira_em).getTime() : 0;
  if (expira - Date.now() > MARGEM_RENOVACAO_MS) return conexao.access_token;

  if (!conexao.refresh_token) {
    throw new Error(`Token expirado e sem refresh token para ${empresa.nome}. Reconecte a empresa.`);
  }
  const refreshExpira = conexao.refresh_expira_em
    ? new Date(conexao.refresh_expira_em).getTime()
    : 0;
  if (refreshExpira && refreshExpira <= Date.now()) {
    throw new Error(`A autorização de ${empresa.nome} expirou. Reconecte a empresa.`);
  }

  try {
    const tokens = await renovarAccessToken(empresa, conexao.refresh_token);
    const dados = dadosToken(tokens);
    if (!tokens.refresh_token) delete dados.refresh_token;
    if (!tokens.refresh_expires_in) delete dados.refresh_expira_em;
    await db.asServiceRole.entities.OlistConexao.update(conexao.id, dados);
    return tokens.access_token;
  } catch (e) {
    await db.asServiceRole.entities.OlistConexao.update(conexao.id, {
      status: "erro",
      ultimo_erro: e.message,
    });
    throw new Error(`Falha ao renovar a autorização de ${empresa.nome}: ${e.message}`);
  }
}