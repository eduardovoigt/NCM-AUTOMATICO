import { secrets } from "base44:runtime";

const API_BASE = "https://api.tiny.com.br/api2";

export const CONTAS = [
  { id: "dugu", nome: "DUGU ATACADISTA", secretName: "TINY_TOKEN_DUGU" },
  { id: "fadrilar", nome: "FADRILAR", secretName: "TINY_TOKEN_FADRILAR" },
];

export function getConta(id) {
  const conta = CONTAS.find((c) => c.id === id);
  if (!conta) throw new Error("Conta inválida: " + id);
  const token = secrets.get(conta.secretName);
  if (!token) throw new Error("Token não configurado para a conta " + conta.nome);
  return { ...conta, token };
}

export function nomeConta(id) {
  return CONTAS.find((c) => c.id === id)?.nome ?? id;
}

export async function call(endpoint, params, contaId) {
  const conta = getConta(contaId);
  const body = new URLSearchParams({ token: conta.token, formato: "json", ...params });
  const url = `${API_BASE}/${endpoint}`;
  const logParams = { ...params };
  if (logParams.token) logParams.token = "[REDACTED]";
  console.log(`[TINY] → POST ${url}`);
  console.log(`[TINY]   params: ${JSON.stringify(logParams).substring(0, 3000)}`);
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: body.toString(),
  });
  const text = await res.text();
  console.log(`[TINY] ← HTTP ${res.status} ${res.statusText} (${text.length} bytes)`);
  console.log(`[TINY]   body: ${text.substring(0, 3000)}`);
  if (!res.ok) {
    throw new Error(`HTTP ${res.status} ${res.statusText} — Resposta: ${text.substring(0, 1000)}`);
  }
  let json;
  try {
    json = JSON.parse(text);
  } catch {
    throw new Error("Resposta inválida do Olist ERP.");
  }
  const ret = json?.retorno;
  if (!ret) throw new Error("Resposta sem 'retorno' do Olist ERP.");
  if (ret.status === "Erro" || ret.status_processamento === 2 || ret.status_processamento === 1) {
    const erros = ret.erros;
    let msg;
    if (Array.isArray(erros)) {
      msg = erros.map((e) => e.erro || e.mensagem || JSON.stringify(e)).join("; ");
    } else if (erros && typeof erros === "object") {
      msg = erros.erro || erros.mensagem || JSON.stringify(erros);
    } else {
      msg = "Erro desconhecido do Olist ERP.";
    }
    throw new Error(msg);
  }
  const registro = ret.registros?.[0]?.registro ?? ret.registros?.registro;
  if (registro && (registro.status === "ERRO" || String(registro.status).toLowerCase() === "rejeitada")) {
    const erros = registro.erros;
    let msg;
    if (Array.isArray(erros)) {
      msg = erros.map((e) => e.erro || e.mensagem || JSON.stringify(e)).join("; ");
    } else if (erros && typeof erros === "object") {
      msg = erros.erro || erros.mensagem || JSON.stringify(erros);
    } else {
      msg = "Nota rejeitada pela SEFAZ.";
    }
    throw new Error(msg);
  }
  return ret;
}

// === NCM ===

const NCM_TABLE = [
  { keywords: ["algodao", "tecido de algodao"], ncm: "52082900" },
  { keywords: ["malha"], ncm: "63021000" },
  { keywords: ["toalha", "tapete"], ncm: "63026000" },
  { keywords: ["fralda", "cueiro", "toalha com capuz"], ncm: "96190000" },
  { keywords: ["mosquiteiro"], ncm: "63031990" },
  { keywords: ["babador"], ncm: "62092000" },
  { keywords: ["travesseiro"], ncm: "94049000" },
  { keywords: ["pano de copa", "pano de prato"], ncm: "63071000" },
  { keywords: ["plastico"], ncm: "39249000" },
  { keywords: ["natal"], ncm: "52121200" },
  { keywords: ["cotonete"], ncm: "56012190" },
];

export const NCM_CONTINGENCIA = "62092000";

function normalize(text) {
  return String(text)
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .trim();
}

export function matchNcm(productTitle) {
  const normalized = normalize(productTitle);
  for (const entry of NCM_TABLE) {
    for (const keyword of entry.keywords) {
      const normKw = normalize(keyword);
      const regex = new RegExp(
        normKw
          .split(/\s+/)
          .map((w) => w.replace(/[.*+?^${}()|[\]\\]/g, "\\$&") + "s?")
          .join("\\s+")
      );
      if (regex.test(normalized)) return entry.ncm;
    }
  }
  return null;
}

export function isNcmError(errorMsg) {
  const lower = String(errorMsg).toLowerCase();
  return (
    lower.includes("ncm") ||
    lower.includes("n.c.m") ||
    lower.includes("classificação fiscal") ||
    lower.includes("classificacao fiscal")
  );
}

// === API ===

export async function listarNotasPendentes(contaId, pagina) {
  let ret;
  try {
    ret = await call(
      "notas.fiscais.pesquisa.php",
      { tipoNota: "S", situacao: "1", pagina: String(pagina || 1) },
      contaId
    );
  } catch (e) {
    if (String(e.message).toLowerCase().includes("não retornou") || String(e.message).toLowerCase().includes("nao retornou")) {
      return { notas: [], pagina: pagina || 1, paginas: 1 };
    }
    throw e;
  }
  const notas = (ret.notas_fiscais ?? []).map((n) => {
    const nf = n.nota_fiscal;
    return {
      id: String(nf?.id ?? ""),
      numero: String(nf?.numero ?? ""),
      serie: nf?.serie ?? "",
      tipo: nf?.tipo ?? "",
      situacao: nf?.situacao ?? "1",
      descricaoSituacao: nf?.descricao_situacao ?? "Pendente",
      cliente: nf?.cliente?.nome ?? nf?.nome ?? "",
      data: nf?.data_emissao ?? "",
      numeroEcommerce: nf?.numero_ecommerce ?? "",
      marketplace: nf?.marketplace ?? nf?.nome_marketplace ?? "",
      valor: nf?.valor ?? "",
      uf: nf?.cliente?.uf ?? "",
    };
  });
  return {
    notas,
    pagina: Number(ret.pagina || pagina || 1),
    paginas: Number(ret.numero_paginas || ret.paginas || 1),
  };
}

export async function obterNota(id, contaId) {
  const ret = await call("nota.fiscal.obter.php", { id }, contaId);
  return ret.nota_fiscal;
}

const num = (v) => {
  const n = Number(String(v ?? "0").replace(",", "."));
  return Number.isFinite(n) ? n : 0;
};

export function extrairItens(nota) {
  return (nota?.itens ?? []).map((wrap) => {
    const item = wrap.item ?? wrap;
    return {
      codigo: item.codigo || "",
      descricao: item.descricao || "",
      unidade: item.unidade || "UN",
      quantidade: num(item.quantidade),
      valor_unitario: num(item.valor_unitario),
      ncm: String(item.ncm || "").replace(/\D/g, ""),
      cfop: item.cfop || "",
      id_produto: item.id_produto || "",
    };
  });
}

// === FORMATAR NCM ===
// A API do Tiny aceita o NCM no formato com máscara: ####.##.##
// Exemplo: 52082900 → 5208.29.00

export function formatarNcm(ncm) {
  const digits = String(ncm || "").replace(/\D/g, "");
  if (digits.length === 8) {
    return `${digits.substring(0, 4)}.${digits.substring(4, 6)}.${digits.substring(6, 8)}`;
  }
  return digits;
}

// === EDITAR NOTA FISCAL EXISTENTE ===
// O fluxo correto é editar SOMENTE o item da nota fiscal que está sem NCM,
// sem tocar no cadastro do produto e sem regenerar/incluir nova nota.

export function montarNotaParaSalvar(nota, itensCorrigidos) {
  const c = nota.cliente || {};
  const t = nota.transportador || {};
  const ee = nota.endereco_entrega || {};
  return {
    nota_fiscal: {
      tipo: nota.tipo_nota === "E" ? "E" : "S",
      natureza_operacao: nota.natureza_operacao || "",
      finalidade: nota.finalidade || "1",
      serie: nota.serie || "1",
      data_emissao: nota.data_emissao || "",
      obs: nota.obs || "",
      ecommerce: nota.numero_ecommerce || "",
      cliente: {
        nome: c.nome || "",
        codigo: c.codigo || "",
        tipo_pessoa: c.tipo_pessoa || "",
        cpf_cnpj: c.cpf_cnpj || "",
        ie: c.ie || "",
        rg: c.rg || "",
        endereco: c.endereco || "",
        numero: c.numero || "",
        complemento: c.complemento || "",
        bairro: c.bairro || "",
        cep: c.cep || "",
        cidade: c.cidade || "",
        uf: c.uf || "",
        pais: c.pais || "",
        fone: c.fone || "",
        email: c.email || "",
        atualizar_cliente: "N",
      },
      endereco_entrega: ee,
      itens: itensCorrigidos.map((i) => ({
        item: {
          id_produto: i.id_produto && String(i.id_produto) !== "0" ? String(i.id_produto) : "",
          codigo: i.codigo || "",
          descricao: i.descricao || "",
          unidade: i.unidade || "Un",
          quantidade: String(i.quantidade || 0),
          valor_unitario: String(i.valor_unitario || 0),
          tipo: "P",
          ncm: i.ncm || "",
          cfop: i.cfop || "",
        },
      })),
      transportador: {
        codigo: t.codigo || "",
        nome: t.nome || "",
        tipo_pessoa: t.tipo_pessoa || "",
        cpf_cnpj: t.cpf_cnpj || "",
        ie: t.ie || "",
        endereco: t.endereco || "",
        cidade: t.cidade || "",
        uf: t.uf || "",
      },
      forma_envio: nota.forma_envio || "",
      frete_por_conta: nota.frete_por_conta || "R",
      placa_veiculo: nota.placa || "",
      uf_placa: nota.uf_placa || "",
      quantidade_volumes: nota.quantidade_volumes || "",
      especie_volumes: nota.especie_volumes || "",
      marca_volumes: nota.marca_volumes || "",
      numero_volumes: nota.numero_volumes || "",
      peso_bruto: nota.peso_bruto || "",
      peso_liquido: nota.peso_liquido || "",
      forma_pagamento: nota.forma_pagamento || "",
      meio_pagamento: nota.meio_pagamento || "",
      parcelas: nota.parcelas || [],
    },
  };
}

export async function alterarNotaFiscal(notaId, notaJson, contaId) {
  console.log(`[ALTERAR] ID da Nota: ${notaId}`);
  console.log(`[ALTERAR] Endpoint: nota.fiscal.alterar.php`);
  console.log(`[ALTERAR] Método: POST`);
  console.log(`[ALTERAR] URL: ${API_BASE}/nota.fiscal.alterar.php`);
  console.log(`[ALTERAR] Payload JSON: ${JSON.stringify(notaJson).substring(0, 5000)}`);
  const ret = await call(
    "nota.fiscal.alterar.php",
    { id: String(notaId), nota: JSON.stringify(notaJson) },
    contaId
  );
  const registro = ret.registros?.[0]?.registro ?? ret.registros?.registro;
  if (registro && String(registro.status).toUpperCase() === "ERRO") {
    const erros = registro.erros;
    let msg = "Erro ao alterar nota";
    if (Array.isArray(erros)) {
      msg = erros.map((e) => e.erro || e.mensagem || JSON.stringify(e)).join("; ");
    } else if (erros && typeof erros === "object") {
      msg = erros.erro || erros.mensagem || JSON.stringify(erros);
    }
    throw new Error(`nota.fiscal.alterar.php: ${msg}`);
  }
  console.log(`[ALTERAR] Nota alterada — id=${registro?.id ?? notaId}`);
  return {
    id: String(registro?.id ?? notaId),
    numero: String(registro?.numero ?? ""),
  };
}

export async function gerarNotaDePedido(pedidoId, contaId) {
  console.log(`[GERAR] Gerando nota fiscal do pedido ${pedidoId}`);
  const ret = await call(
    "gerar.nota.fiscal.pedido.php",
    { id: String(pedidoId), modelo: "NFe" },
    contaId
  );
  const registro = ret.registros?.[0]?.registro ?? ret.registros?.registro;
  const novaNota = {
    id: String(registro?.idNotaFiscal ?? registro?.id ?? ""),
    numero: String(registro?.numero ?? ""),
    serie: String(registro?.serie ?? ""),
  };
  console.log(`[GERAR] Nova nota gerada: id=${novaNota.id}, numero=${novaNota.numero}, serie=${novaNota.serie}`);
  return novaNota;
}

export async function emitirNota(id, contaId) {
  const ret = await call("nota.fiscal.emitir.php", { id }, contaId);
  return ret;
}

// === INCLUIR NOVA NOTA FISCAL COM NCM CORRIGIDO ===
// Como a API do Tiny não permite alterar itens de uma nota existente,
// criamos uma nova nota com os mesmos dados da original, mas com o NCM
// corrigido diretamente em cada item.

export function montarNotaParaIncluir(nota, itensCorrigidos) {
  const c = nota.cliente || {};
  const t = nota.transportador || {};
  const ee = nota.endereco_entrega || {};
  return {
    nota_fiscal: {
      tipo: nota.tipo_nota === "E" ? "E" : "S",
      natureza_operacao: nota.natureza_operacao || "",
      finalidade: nota.finalidade || "1",
      serie: nota.serie || "1",
      data_emissao: nota.data_emissao || "",
      obs: nota.obs || "",
      ecommerce: nota.numero_ecommerce || "",
      cliente: {
        nome: c.nome || "",
        codigo: c.codigo || "",
        tipo_pessoa: c.tipo_pessoa || "",
        cpf_cnpj: c.cpf_cnpj || "",
        ie: c.ie || "",
        rg: c.rg || "",
        endereco: c.endereco || "",
        numero: c.numero || "",
        complemento: c.complemento || "",
        bairro: c.bairro || "",
        cep: c.cep || "",
        cidade: c.cidade || "",
        uf: c.uf || "",
        pais: c.pais || "",
        fone: c.fone || "",
        email: c.email || "",
        atualizar_cliente: "N",
      },
      endereco_entrega: ee,
      itens: itensCorrigidos.map((i) => ({
        item: {
          id_produto: i.id_produto && String(i.id_produto) !== "0" ? String(i.id_produto) : "",
          codigo: i.codigo || "",
          descricao: i.descricao || "",
          unidade: i.unidade || "Un",
          quantidade: String(i.quantidade || 0),
          valor_unitario: String(i.valor_unitario || 0),
          tipo: "P",
          ncm: i.ncm || "",
          cfop: i.cfop || "",
        },
      })),
      transportador: {
        codigo: t.codigo || "",
        nome: t.nome || "",
        tipo_pessoa: t.tipo_pessoa || "",
        cpf_cnpj: t.cpf_cnpj || "",
        ie: t.ie || "",
        endereco: t.endereco || "",
        cidade: t.cidade || "",
        uf: t.uf || "",
      },
      forma_envio: nota.forma_envio || "",
      frete_por_conta: nota.frete_por_conta || "R",
      placa_veiculo: nota.placa || "",
      uf_placa: nota.uf_placa || "",
      quantidade_volumes: nota.quantidade_volumes || "",
      especie_volumes: nota.especie_volumes || "",
      marca_volumes: nota.marca_volumes || "",
      numero_volumes: nota.numero_volumes || "",
      peso_bruto: nota.peso_bruto || "",
      peso_liquido: nota.peso_liquido || "",
      forma_pagamento: nota.forma_pagamento || "",
      meio_pagamento: nota.meio_pagamento || "",
      parcelas: nota.parcelas || [],
    },
  };
}

export async function incluirNota(notaJson, contaId) {
  console.log(`[INCLUIR] Incluindo nova nota fiscal`);
  const ret = await call(
    "nota.fiscal.incluir.php",
    { nota: JSON.stringify(notaJson) },
    contaId
  );
  const registro = ret.registros?.[0]?.registro ?? ret.registros?.registro;
  if (registro && String(registro.status).toUpperCase() === "ERRO") {
    const erros = registro.erros;
    let msg = "Erro ao incluir nota";
    if (Array.isArray(erros)) {
      msg = erros.map((e) => e.erro || e.mensagem || JSON.stringify(e)).join("; ");
    } else if (erros && typeof erros === "object") {
      msg = erros.erro || erros.mensagem || JSON.stringify(erros);
    }
    throw new Error(`nota.fiscal.incluir.php: ${msg}`);
  }
  return {
    id: String(registro?.id ?? ""),
    numero: String(registro?.numero ?? ""),
  };
}